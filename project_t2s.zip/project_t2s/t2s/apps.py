from django.apps import AppConfig


class T2SConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 't2s'
